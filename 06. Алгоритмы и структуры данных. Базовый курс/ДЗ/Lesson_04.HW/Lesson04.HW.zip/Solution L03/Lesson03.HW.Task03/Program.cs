﻿using System;

using static mlConsole.PrintData;

namespace Lesson03.HW.Task03
{
    class Program
    {


    }
}
