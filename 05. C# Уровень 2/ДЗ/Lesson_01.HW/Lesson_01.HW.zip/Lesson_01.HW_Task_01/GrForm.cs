﻿using System.Windows.Forms;

namespace MyGame
{
    public partial class GrForm : Form
    {
        public GrForm()
        {
            InitializeComponent();
        }
    }
}
