<div class="header">
			<a href="index.php"><b>Главная</b></a>
			<a href="gameRiddles.php"><b>Загадки</b></a>
			<a href="gameNumbers.php"><b>Угадай число</b></a>
			<a href="passGen.php"><b>Генератор пароля</b></a>
</div>