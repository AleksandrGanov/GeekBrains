<div class="footer">
		<p>Copyright &copy; <?php echo date("Y"); ?> Ganov Aleksandr</p>
</div>
