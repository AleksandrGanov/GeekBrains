﻿/* 
Задача №2. Ганов Александр Анатольевич
----------------------------------------------------
Описание задания:
~~~~~~~~~~~~~
Создайте простую форму на котором свяжите свойство Text элемента TextBox со свойством Value элемента NumericUpDowe
 */

using System.Windows.Forms;

namespace Lesson_08.HW_Task_02
{
    class Program
    {
        static void Main(string[] args)
        {
            Application.Run(new frmTask02());
        }
    }
}
